%> @brief Represents the units types
classdef A3200UnitsType < int32
  enumeration
    %> @brief Secondary units
    Secondary (0)
    %> @brief Primary units
    Primary (1)
  end
end
